package minimarket.modelo.A2Mercado.DataBase;

import java.sql.*;

public class DatabaseConnection {
    private static final String URL = "jdbc:sqlite:minimercado.db";
    private static Connection connection;

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(URL);
        }
        return connection;
    }

    public static void initDatabase() {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {

            // Tabela produtos
            String sqlProdutos = "CREATE TABLE IF NOT EXISTS produtos (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "nome VARCHAR(100) NOT NULL, " +
                    "descricao TEXT, " +
                    "preco DECIMAL(10,2) NOT NULL, " +
                    "quantidade INTEGER NOT NULL, " +
                    "data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
            stmt.execute(sqlProdutos);

            // Tabela clientes
            String sqlClientes = "CREATE TABLE IF NOT EXISTS clientes (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "nome VARCHAR(100) NOT NULL, " +
                    "email VARCHAR(100), " +
                    "telefone VARCHAR(20), " +
                    "cpf VARCHAR(14) UNIQUE)";
            stmt.execute(sqlClientes);

            // Tabela vendas
            String sqlVendas = "CREATE TABLE IF NOT EXISTS vendas (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "cliente_id INTEGER, " +
                    "data_venda TIMESTAMP DEFAULT CURRENT_TIMESTAMP, " +
                    "total DECIMAL(10,2) NOT NULL, " +
                    "forma_pagamento VARCHAR(50), " +
                    "FOREIGN KEY (cliente_id) REFERENCES clientes(id))";
            stmt.execute(sqlVendas);

            // Tabela itens_venda
            String sqlItensVenda = "CREATE TABLE IF NOT EXISTS itens_venda (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "venda_id INTEGER, " +
                    "produto_id INTEGER, " +
                    "quantidade INTEGER NOT NULL, " +
                    "preco_unitario DECIMAL(10,2) NOT NULL, " +
                    "FOREIGN KEY (venda_id) REFERENCES vendas(id), " +
                    "FOREIGN KEY (produto_id) REFERENCES produtos(id))";
            stmt.execute(sqlItensVenda);

            // Inserir dados iniciais
            String insertProdutos = "INSERT OR IGNORE INTO produtos (nome, descricao, preco, quantidade) VALUES " +
                    "('Arroz', 'Arroz branco tipo 1', 25.90, 50), " +
                    "('Feijão', 'Feijão carioca', 8.50, 30), " +
                    "('Açúcar', 'Açúcar refinado', 4.75, 40), " +
                    "('Café', 'Café torrado e moído', 12.90, 25), " +
                    "('Óleo', 'Óleo de soja', 7.80, 35)";
            stmt.execute(insertProdutos);

            String insertClientes = "INSERT OR IGNORE INTO clientes (nome, email, telefone, cpf) VALUES " +
                    "('João Silva', 'joao@email.com', '(11) 9999-8888', '123.456.789-00'), " +
                    "('Maria Santos', 'maria@email.com', '(11) 7777-6666', '987.654.321-00')";
            stmt.execute(insertClientes);

        } catch (SQLException e) {
            System.err.println("Erro ao criar banco: " + e.getMessage());
        }
    }
}